Font Awesome
==========

Used in H5P libraries to provide icons. FontAwesome is no longer a part of core.
`font-family: 'H5PFontAwesome4';` is used to avoids collisions.
The woff(W3C Recommendation) font file is included inline to avoid cross origin issues when embedding on some browsers.

## License

Font Awesome font licensed under SIL OFL 1.1 · Code licensed under MIT License
http://fontawesome.io/license
Created by @davegandy.
